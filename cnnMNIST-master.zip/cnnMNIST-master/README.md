# cnnMNIST
this is a simplified version of cnn to train and test MNIST

#Usage:
just make to generate the exe file and run it

