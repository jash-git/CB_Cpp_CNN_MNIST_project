#include "math.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"

#define UCHR unsigned char
#define UINT unsigned int

const UINT g_cImageSize = 28;
const UINT g_cVectorSize = 29;
const UINT g_cOutputSize = 10;
//const UINT g_cCountTrainingSample = 60000;
//const UINT g_cCountTestingSample = 10000;
const UINT g_cCountTrainingSample = 60000;
const UINT g_cCountTestingSample = 10000;



